# Smart Review System - Subagent実装アプローチ（修正版）

*対象環境: Claude Code CLI*
*アプローチ: Subagents + オーケストレーション*
*元のアーキテクチャを尊重した実装*

## 📋 元の設計の再確認

提供されたドキュメント（orchestration_reference.md、skills_orchestration_guide.md）は、
以下の「エージェント」アーキテクチャを想定していました：

```
スラッシュコマンド（オーケストレーター）
    ↓
┌─────────────────────────────────────┐
│ Phase 1: Critical/High（順次）      │
│   ├─ Security Analyzer             │
│   └─ Super Debugger                 │
├─────────────────────────────────────┤
│ Phase 2: Medium/Low（並列）         │
│   ├─ Deep Code Reviewer             │
│   └─ Documentation Updater          │
└─────────────────────────────────────┘
    ↓
結果統合・TODOリスト生成
```

## 🎯 Claude Code CLIでの正しい実装

### アーキテクチャ

```
プロジェクトルート/
├── .claude/
│   ├── commands/
│   │   ├── smart-review.md          # メインオーケストレーター
│   │   ├── review-changes.md        # 差分レビュー
│   │   └── review-security.md       # セキュリティのみ
│   ├── agents/                      # ★ Subagents
│   │   ├── security-analyzer.md
│   │   ├── super-debugger.md
│   │   ├── code-reviewer.md
│   │   └── doc-updater.md
│   └── skills/                      # オプション：補助Skills
│       └── result-aggregator/
└── CLAUDE.md
```

## 📝 実装詳細

### 1. メインオーケストレーター（スラッシュコマンド）

**`.claude/commands/smart-review.md`**

```markdown
---
description: 複数の専門エージェントによる包括的コードレビュー
---

# Smart Review System - Main Orchestrator

このコマンドは、4つの専門エージェントを順次実行してコードレビューを行います。

## 実行フロー

### Phase 1: Critical/High Priority（順次実行）

**1. Security Analyzer（セキュリティ分析）**
```
security-analyzer subagentを使用して、セキュリティ脆弱性を分析してください。

対象: {files}
出力形式: JSON

分析後、結果をセキュリティ分析結果として保存してください。
```

**2. Super Debugger（デバッグ分析）**
```
super-debugger subagentを使用して、バグとロジックエラーを検出してください。

対象: {files}
出力形式: JSON

分析後、結果をデバッグ分析結果として保存してください。
```

### Phase 2: Medium/Low Priority（並列可能）

**3. Code Reviewer（品質分析）**
```
code-reviewer subagentを使用して、コード品質を評価してください。

対象: {files}
出力形式: JSON
```

**4. Documentation Updater（ドキュメント分析）**
```
doc-updater subagentを使用して、ドキュメント完全性をチェックしてください。

対象: {files}
出力形式: JSON
```

### 結果統合

全てのエージェント実行完了後、以下を生成：

1. **統合レポート**
   - 検出問題の総数
   - 重要度別の内訳
   - カテゴリー別の内訳

2. **TODOリスト（Markdown）**
   ```markdown
   # Smart Review TODO List
   
   ## Critical Priority (X件)
   - [ ] [Security] 問題の説明
     - 場所: ファイル:行
     - 推奨: 修正方法
     - 工数: 30m
   
   ## High Priority (X件)
   ...
   ```

3. **メトリクス**
   - 実行時間
   - 分析ファイル数
   - 検出問題数
   - 自動修正可能数

## 実行方法

```bash
# 基本実行
/smart-review

# 引数指定
/smart-review src/
/smart-review --scope changes
```
```

### 2. Subagent定義

#### Security Analyzer

**`.claude/agents/security-analyzer.md`**

```markdown
---
name: security-analyzer
description: セキュリティ脆弱性を検出する専門エージェント。XSS、SQLi、認証問題などCritical/High優先度の問題を分析します。
tools: Read, Bash
---

# Security Analyzer Subagent

あなたはセキュリティ専門のコード分析エージェントです。

## 専門分野

- XSS (Cross-Site Scripting) - CWE-79
- SQLインジェクション - CWE-89
- コマンドインジェクション - CWE-78
- 認証・認可の問題
- 機密情報の露出
- 暗号化の不備

## 分析プロセス

1. **ファイルの読み込み**
   - 指定されたファイルを順次読み込み
   - コンテキストを理解

2. **パターンマッチング**
   - 既知の脆弱性パターンを検索
   - 正規表現とセマンティック分析を併用

3. **脆弱性の評価**
   - 重要度の判定（Critical/High/Medium/Low）
   - CWEマッピング
   - 攻撃シナリオの想定

4. **修正推奨の生成**
   - 具体的な修正方法
   - コード例の提供
   - 自動修正可否の判定

## 出力形式

**必須**: 以下のJSON形式で出力してください：

```json
{
  "agent": "security-analyzer",
  "timestamp": "ISO-8601",
  "summary": "分析の概要",
  "filesAnalyzed": 数値,
  "issuesFound": 数値,
  "issues": [
    {
      "severity": "critical",
      "type": "XSS",
      "cwe": "CWE-79",
      "file": "src/index.js",
      "line": 42,
      "code": "該当コード",
      "description": "ユーザー入力が直接DOMに挿入されています",
      "impact": "攻撃者が任意のJavaScriptを実行可能",
      "recommendation": "textContent を使用するか、DOMPurify でサニタイズしてください",
      "example": "コード例",
      "autoFixable": true,
      "estimatedEffort": "30m"
    }
  ]
}
```

## 検出パターン例

### XSS
- `innerHTML = ` → ユーザー入力の直接挿入
- `dangerouslySetInnerHTML` → React での危険な使用
- `document.write()` → 動的なHTML生成

### SQLインジェクション
- `"SELECT * FROM users WHERE id = " + userId` → 文字列連結
- `query(sql + input)` → 未検証入力
- `execute("... " + param)` → プリペアドステートメント未使用

### コマンドインジェクション
- `exec(command + userInput)` → シェルコマンド構築
- `eval(userInput)` → 動的コード実行
- `child_process.exec(...)` → 検証なし実行

## 重要な原則

1. **誤検出の最小化**: 高精度な分析
2. **実用的な推奨**: 実装可能な修正方法
3. **優先順位付け**: Critical問題を優先
4. **文脈の考慮**: ビジネスロジックを理解

## 対応言語

- JavaScript/TypeScript
- Python
- Java
- Go
- PHP
- Ruby

## 制約事項

- ビルド生成ファイルは分析対象外
- node_modules/は除外
- .min.jsファイルは除外
```

#### Super Debugger

**`.claude/agents/super-debugger.md`**

```markdown
---
name: super-debugger
description: バグとロジックエラーを検出する専門エージェント。null参照、型エラー、例外処理の不備などHigh優先度の問題を分析します。
tools: Read, Bash
---

# Super Debugger Subagent

あなたはバグ検出専門のコード分析エージェントです。

## 専門分野

- null/undefined参照
- 型の不一致
- ロジックエラー
- 例外処理の不備
- メモリリーク
- レースコンディション
- エッジケースの未処理

## 分析プロセス

1. **静的解析**
   - AST（抽象構文木）の解析
   - データフローの追跡
   - 制御フローの検証

2. **パターン検出**
   - 一般的なバグパターン
   - アンチパターン
   - 潜在的な問題箇所

3. **型チェック**
   - TypeScript型定義との整合性
   - 暗黙的な型変換
   - 型安全性の検証

4. **ロジック検証**
   - 条件分岐の網羅性
   - ループの正当性
   - エッジケースの処理

## 出力形式

```json
{
  "agent": "super-debugger",
  "timestamp": "ISO-8601",
  "summary": "分析の概要",
  "filesAnalyzed": 数値,
  "issuesFound": 数値,
  "issues": [
    {
      "severity": "high",
      "type": "NullReference",
      "file": "src/utils.js",
      "line": 56,
      "code": "該当コード",
      "description": "nullまたはundefinedの可能性があるオブジェクトにアクセス",
      "scenario": "userオブジェクトがnullの場合にクラッシュ",
      "recommendation": "Optional chainingまたはnullチェックを追加",
      "example": "user?.profile?.name ?? 'Unknown'",
      "autoFixable": true,
      "estimatedEffort": "15m"
    }
  ]
}
```

## 検出パターン例

### null/undefined参照
- `obj.property` → nullチェックなし
- `array[0]` → 空配列の可能性
- `response.data.items` → 深いネスト

### 型エラー
- `number + string` → 暗黙的な型変換
- `parseInt(undefined)` → NaN生成
- 型アサーションの誤用

### ロジックエラー
- `if (x = 5)` → 代入と比較の混同
- `arr.length > 0` → 境界条件
- 無限ループの可能性

### 例外処理
- try-catchの不足
- `catch (e) {}` → エラーの握りつぶし
- 非同期エラーの未処理
```

#### Code Reviewer（品質分析）

**`.claude/agents/code-reviewer.md`**

```markdown
---
name: code-reviewer
description: コード品質を評価する専門エージェント。複雑度、保守性、設計パターン、コードスメルなどMedium優先度の問題を分析します。
tools: Read, Bash
---

# Code Reviewer Subagent

あなたはコード品質評価専門のエージェントです。

## 専門分野

- 循環的複雑度
- コードスメル
- 設計原則（SOLID、DRY）
- 命名規則
- 保守性

## 評価観点

### 1. 複雑度メトリクス
- 関数の行数
- ネストレベル
- 分岐の数
- McCabe複雑度

### 2. コードスメル
- 長すぎる関数（>50行）
- 長すぎるパラメータリスト（>5個）
- 重複コード
- デッドコード
- マジックナンバー
- 不適切な命名

### 3. 設計原則
- Single Responsibility（単一責任）
- Open/Closed（開放/閉鎖）
- DRY（Don't Repeat Yourself）
- YAGNI（You Aren't Gonna Need It）

### 4. 保守性
- コメントの適切性
- テスタビリティ
- 依存関係の管理
- モジュール分割

## 出力形式

```json
{
  "agent": "code-reviewer",
  "timestamp": "ISO-8601",
  "summary": "品質評価の概要",
  "overallScore": 75,
  "filesAnalyzed": 数値,
  "issuesFound": 数値,
  "issues": [
    {
      "severity": "medium",
      "type": "Complexity",
      "file": "src/processor.js",
      "line": 89,
      "metric": "Cyclomatic Complexity",
      "value": 18,
      "threshold": 10,
      "description": "この関数の循環的複雑度が高すぎます",
      "recommendation": "関数を小さく分割してください",
      "example": "ヘルパー関数の抽出例",
      "autoFixable": false,
      "estimatedEffort": "2h"
    }
  ]
}
```
```

#### Documentation Updater

**`.claude/agents/doc-updater.md`**

```markdown
---
name: doc-updater
description: ドキュメント完全性をチェックする専門エージェント。JSDoc、コメント、README、型定義などLow優先度の問題を分析します。
tools: Read, Bash
---

# Documentation Updater Subagent

あなたはドキュメント品質評価専門のエージェントです。

## 専門分野

- JSDoc/TSDoc
- インラインコメント
- README/使用方法
- 型定義の明確性
- API仕様書

## 評価観点

### 1. 関数ドキュメント
- パブリック関数のJSDoc完全性
- パラメータ説明
- 戻り値の説明
- 例外の説明
- 使用例

### 2. コメント品質
- 複雑なロジックの説明
- TODOコメントの管理
- 不要なコメントの検出
- コメントの正確性

### 3. プロジェクトドキュメント
- README.mdの完全性
- インストール手順
- 使用方法
- APIリファレンス
- トラブルシューティング

## 出力形式

```json
{
  "agent": "doc-updater",
  "timestamp": "ISO-8601",
  "summary": "ドキュメント評価の概要",
  "coverageScore": 65,
  "filesAnalyzed": 数値,
  "issuesFound": 数値,
  "issues": [
    {
      "severity": "low",
      "type": "MissingJSDoc",
      "file": "src/api.js",
      "line": 45,
      "function": "processRequest",
      "description": "public関数にJSDocコメントがありません",
      "recommendation": "JSDocコメントを追加してください",
      "template": "JSDocテンプレート例",
      "autoFixable": true,
      "estimatedEffort": "10m"
    }
  ]
}
```
```

## 🎯 実行例

### 基本実行

```bash
claude

> /smart-review
```

**内部動作：**
1. オーケストレーターが起動
2. security-analyzer subagent 実行
3. super-debugger subagent 実行
4. code-reviewer と doc-updater を並列実行
5. 結果を統合してTODOリスト生成

### 差分レビュー

```bash
> /review-changes
```

### セキュリティのみ

```bash
> /review-security
```

## 📊 実装の違い

### 元の提案（Skillsベース）との違い

| 観点 | Skillsベース | Subagentsベース（現在） |
|------|-------------|----------------------|
| **呼び出し** | Claude自動選択 | 明示的に指定 |
| **制御** | 暗黙的 | 明示的 |
| **順序保証** | なし | あり |
| **オーケストレーション** | 不要 | 必要 |
| **元の設計** | 不一致 | 完全一致 ✅ |

## 🔧 技術的な利点

### Subagentsアプローチの利点

1. **明示的な制御**
   - 実行順序を完全に制御
   - エラーハンドリングが容易
   - デバッグが簡単

2. **元の設計の尊重**
   - ドキュメントのアーキテクチャと一致
   - オーケストレーションロジックを維持
   - 段階的実行（Phase 1→2）を実現

3. **結果の確実な統合**
   - 各エージェントの出力を確実に取得
   - JSON形式での構造化
   - 統一的なレポート生成

## 📝 実装スケジュール（修正版）

### Week 1: オーケストレーター + Security Analyzer
- スラッシュコマンド実装
- Security Analyzer subagent実装
- テスト

### Week 2: Super Debugger
- Super Debugger subagent実装
- Phase 1統合テスト

### Week 3: Code Reviewer + Doc Updater
- Code Reviewer subagent実装
- Doc Updater subagent実装
- Phase 2統合テスト

### Week 4: 統合・レポート生成
- 結果統合ロジック
- TODOリスト生成
- HTMLレポート生成
- 総合テスト

## 🎓 まとめ

**前回の提案の問題点：**
❌ 元のドキュメントの「エージェント」概念を無視
❌ Skillsとして再解釈してしまった
❌ オーケストレーションの価値を軽視

**今回の提案：**
✅ 元のアーキテクチャを完全に尊重
✅ Subagentsとして実装
✅ 明示的なオーケストレーション
✅ 段階的実行の実現
✅ 結果統合の確実性

この実装により、提供されたドキュメントの設計思想を
Claude Code CLI環境で正確に再現できます。

---

*作成日: 2025年11月17日*
*修正理由: 元のドキュメントのエージェント概念を正しく反映*
